function outputStringArray = split_string(inputCellArray, delimiters)
%      outputStringArray = split_string(inputCellArray, delimiters);
%  This splits apart the entries of a cell string at delimiter.  The result
%  is a longer cell string, with each entry being split at a delimiter.
%  The delimiters are removed; there are no delimiters in
%  outputStringArray.  The default delimiters are both comma (,) and
%  semicolon (;).  This function is particularly useful when used 
%  with a 2-D spreadsheet or a Matlab
%  table, where a database would include multiple entries/alternatives, 
%  but on a spreadsheet there is only room for one entry.
%  OUTPUTS:
%       outputStringArray = cell string.  Puts each cell into a new cell, 
%           but also divides each input at delimiter, and does not include
%           delimiter.  Also removes white spaces
%  INPUTS:
%       inputCellArray = cell string you want to break down
%       delimiters = string OR cell string.  Will break apart input at
%           these characters, eg a comma ','.  Can use escape characters
%           from regexpi, can use multiple single-character delimiters using brackets (eg
%           '[,;:]' will break at any of the three punctuations), and can
%           use a mutli-character delimiter (e.g. '<.*?>' will find and
%           remove xml commands).  The delimiters are removed and are not
%           returned in the output.  If you want to use more than one
%           delimiter, esp a multi-character delimiter, the delimiter can
%           be a cell string with each delimiter string in one cell.
if ischar(inputCellArray)
    inputCellArray = {inputCellArray};
elseif iscellstr(inputCellArray)
    %  corrrect, carry on
else
    error('Input should be a string or cell string')
end;  %  

if nargin < 2
    delimiters = '[;,]';
end;  %  

outputStringArray = cell(10 * numel(inputCellArray),1);

i_output = 1;  %  set for next entry, ie one ahead
for i_inputs = 1:numel(inputCellArray)
    thisInputCell = inputCellArray{i_inputs};
    if ischar(delimiters)
        substrings = strtrim(regexpi(thisInputCell, delimiters,'split'));
        numStrings = numel(substrings);
        outputStringArray(i_output:(i_output + numStrings -1)) = vert(substrings);
        i_output = i_output + numStrings;
    elseif iscellstr(delimiters)
        substrings = thisInputCell;
        for i_delim = 1:numel(delimiters)
            thisDelimiter = delimiters{i_delim};
            substrings = split_string(substrings, thisDelimiter);
        end;  %  next i_delim
        numStrings = numel(substrings);
        outputStringArray(i_output:(i_output + numStrings -1)) = vert(substrings);
        i_output = i_output + numStrings;
    end;  %  if ischar(delimiters)
end;  %  for i_inputs 


%%  ELIMINATE EXTRA PRE-ALLOCATED CELLS
if i_output <= numel(outputStringArray)
    outputStringArray(i_output:end) = [];
end;  %  

%%  ELIMINATE EMPTY CELLS
%     This is crucial in cases where the user accidentally has two
%     delimiters next to teach other.
outputStringArray = strtrim(outputStringArray);
ix_empties = cellfun('isempty', outputStringArray);
outputStringArray(ix_empties) = [];
