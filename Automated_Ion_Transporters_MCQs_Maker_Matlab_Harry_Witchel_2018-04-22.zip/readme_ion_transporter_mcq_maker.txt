ion_transporters_mcq_maker readme file

VERSION
2018-04-09	01.00	As initially posted

WHO IS THIS SCRIPT FOR
This script is for course leaders and administrators for a pharmacology course.  No background in programming or Matlab is needed.  You can give this collection of scripts and functions (along with the input formulary in excel format) to a colleague who has a copy of Matlab, and they should be able to run the entire process in a minute, without understanding the process.  

PURPOSE
This is a Matlab script (and 11 associated functions) that can be used to automatically make formative multiple choice questions about ion transporters based on a spreadsheet of transporter information (the formulary).  As stated in the explanatory material, the course leader should check the output of this script (i.e. each question/item) to make sure that each question is correct; due to the nature of this script, it is possible for the script to occasionally make a question with more than one correct answer.

HOW TO RUN THIS
Put all the relevant scripts, functions and excel sheets in the current working directory of Matlab, then type "ion_transporters_mcq_maker" (without the quotation marks).

WILL THIS SCRIPT WORK ON OCTAVE
This script has never been tested on Octave.  You will need to load the input/output library to read the xls file.  I would be interested in knowing how you get on.

CAVEATS AND RECOMMENDATIONS
This script is provided as is, with no guarantees for fitness or suitability to your purpose.  Significant attempts were made to test the script, but we cannot guarantee that it will work on all forms of Matlab for all people.  It was tested on Matlab R2016a, and it does not require any specialist Matlab toolboxes.

The most likely problems you may have are as follows:
   1)  Questions/items produced with more than one correct answer.  The questions are only as robust as the entries in the formulary.  We insist that before you release questions produced by this script to your students, that 
        *   All questions produced are vetted by the course leader to make sure that each question is correct.  THIS IS ESSENTIAL.
   2)  Adverse effects questions have the potential to be troublesome because there may be synonyms that the script does not recognise are similar.  
   3)  Synonyms and alternative spellings will cause problems.  Even adding a hyphen will cause two entries to be seen as different.  For example, "NHE-3" and �NHE3� will be treated as two different Na/H exchangers, and therefore one may be used as a wrong option for the other.  We strongly recommend:
     *  Check the output lists for duplicates.  In the output excel file, in addition to the worksheet with the items/questions, there are worksheets showing a complete list of transporter names, transporter genes, functions and inhibitors.  These lists are in alphabetical order.  You should check those lists for synonyms and near duplicates, and if there are any duplicates, you should change your formulary accordingly and then re-run the script from scratch.
      *  When you launch your questions/items for your students, there should be a mechanism for students to flag/complain about questions that they think are incorrect, and these should be corrected as quickly as possible.  To allow for these corrections, I strongly recommend that the questions/items are given unique identifier codes that the students can see and refer to.
   4)  If you have the date function or the category function enabled (or especially both), there is a potential for some questions to have insufficient wrong options.
      *  In your formulary, check that your first date has sufficient entries (in the same category if appropriate).  Thus, if you are making multiple choice questions with five options, you should be certain that lecture 1 is associated with at least five drugs (all in the same category if you have enabled both dates and categories).

WHAT IS INCLUDED
   ion_transporters_mcq_maker.m is the master script.  Note that it is a script (not a function), so you should not use it while working on your own materials in Matlab's current directory.
   Ion Transport input data 2018-04-23.xls is a listing of ion transporters in the correct excel format for use with this script.  You should alter it (or make your own in the same format) in order to use for your educational course.  This file can be easily visualised and edited in excel, and presumably in the open source excel clones in openoffice and libreoffice.
   The following are the included, non-standard functions in Matlab that are needed for mcq_maker to run:
   split_string.m: breaks apart text (as strings or cell strings) at a delimiter (comma or semicolon) to create extra cells in a cell string.  This allows you to use 2-D tables (such as excel spread sheets) as having multiple separate entries inside a single cell.
   nameclean.m: helps get rid of or replace characters (e.g. spaces) when creating file names or titles.  Helps to get rid of white space, but even in the middle of a string.
   regexpcmp.m: originally made by Jason Kaeding, and he has provided permission for me to present it here.  A mixture of strcmp and regexp, it provides a Boolean output to indicate whether a regular expression is included in the query (either a string or cell string).  If the query is a cell string, regexpcmp provides a vector with one Boolean for each cell.
   regexpcmpmulti.m: works like regexpcmp, but allows for multiple regular expressions (as a cell string) to be sought inside the query.  Output is true if ANY of the regular expressions is in the query cell.  Note: this uses loops and is slow.
   isanumber.m: tests whether input is a scalar, finite, non-imaginary number.  Useful in Matlab if you are worried about an input being an NaN, infinite, empty, character string, etc.
   select_from_list.m: provides a text based input in the command window that allows a user to select from a series of strings (input inside a cell string).  Useful for errors and when a script cannot find what it is looking for.  Probably I should have written this for a UI window, but I wrote it a long time ago, and it still works.
   allnines.m: this works with select_from_list, and it recognises when the user rejects all the offered options by letting the user type 999.
   vert.m: for vectors, it will take horizontal vectors (or vertical ones) and make sure they are vertical.  similar to the (:) function, except that vert works in the middle of long lines of code.
   thisDrive.m: No input arguments.  Provides the current drive letter plus a colon as a string.  Useful if you work on multiple computers (or off a USB stick) and the folder directory tree is always the same but the drive letter assigned is unpredictable.  Of course, you could avoid this problem just by using relative directory names.
   dateToday.m: No input arguments.  Provides the current date as a string in the format yyyy-mm-dd (e.g. '2016-01-31' for 31 January 2016).
   warning_off.m: No input arguments.  This suppresses the Matlab warning that usually appears whenever you write a worksheet into excel using xlswrite.

WHO TO BLAME
This code (with the exception of the regexpcmp function) was written by Harry J. Witchel.  It is part of an educational research project at Brighton and Sussex Medical School in the UK.  The project team includes Claire Smith, Darrell Evans (our inspiration), the Synap team, and Joseph H. Guppy.  The project was sponsored by the University of Sussex�s Excellence in teaching awards, and by the University of Brighton�s Centre for Learning and Teaching Scholarship programme.  To make comments or request improvements, contact Harry Witchel; I can be looked up on the web, or usually found via my website www.harrywitchel.com.

COPYRIGHT
This is provided with a Lesser General Public GNU-free license.  You can re-use or re-purpose the code for any academic, charitable, or non-commercial purpose, so long as you include a reference or citation back to the original stating where you received this code from.

CITATION
Currently this is unpublished.  This will be updated when published.

