function output = nameclean(string2clean,optionSpaceOrUnderscore)
%  function output = nameclean(string2clean,optionSpaceOrUnderscore)
%  this function guarantees that a string that will be used for a name,
%  title, file name, graph title etc. does not have multiple spaces or
%  underscores.  It gets rid of all punctuation (except in option 3)
%  There are three options: 
%       spaces between words: (1) optionSpaceOrUnderscore == ' ', or 
%       underscores between words (2) optionSpaceOrUnderscore == '_' or
%       spaces between words while maintaining dashes (3) optionSpaceOrUnderscore == '-'
%  If you do not include an option, the default is (1), spaces between
%  words.
%  USES AND APPLICATIONS
%     This is useful for turning graph titles into file names for saving.  In
%  file names, it is sometimes preferable to have underscores rather than
%  spaces (especially for the web). while matlab titles translate
%  underscores as subscripts, so graph titles must avoid underscores.
%     In graph titles you may like mutliple spaces, and nameclean gets
%  rid of the excess spaces for file names.
%     When comparing two strings that have escape characters (e.g. path names)
%  using regexp (e.g. when looking to see if a large path name contains a
%  small path name), if you clean the strings then regexp can recognise them.
%   
%  EXAMPLE:
%  graphTitle = 'Figure 21 - Velocity vs. Time - Volunteer 07';
%  title(gcf, graphTitle, 'FontSize', 14, 'FontWeight','bold')
%  saveTitle = nameclean(graphTitle, '_');
%  fprintf('     %s\n', saveTitle)
%     Figure_21_Velocity_vs_Time_Volunteer_07
% 
%  Version   01.00  2018-04-10
%  Copyright 2018 Harry J. Witchel
%  Supplied with Gnu free license.  Free to re-use and re-purpose for all
%  academic, charitable and non-commercial uses, so long as the
%  author/source of the original code is cited.

%%  decide on option
if nargin < 2
    optionSpaceOrUnderscore = 'space';
    option = 1;
end;  %  if nargin < 2

if ischar(optionSpaceOrUnderscore)
    if strcmpi(optionSpaceOrUnderscore(1),'S')  % SPACE
        option = 1;
    elseif strcmpi(optionSpaceOrUnderscore(1),'U')  % UNDERSCORE
        option = 2;
    elseif strcmpi(optionSpaceOrUnderscore(1),' ')  % SPACE
        option = 1;
    elseif strcmpi(optionSpaceOrUnderscore(1),'_')  % UNDERSCORE
        option = 2;
    elseif strcmpi(optionSpaceOrUnderscore(1),'-')  % DASH
        option = 3;
    elseif strcmpi(optionSpaceOrUnderscore(1),'D')  % DASH
        option = 3;
    else
        option = 1;
    end;  %  
elseif isnumeric(optionSpaceOrUnderscore) && isanumber(optionSpaceOrUnderscore) && ...
        (optionSpaceOrUnderscore == floor(optionSpaceOrUnderscore)) && ...
        inrange(optionSpaceOrUnderscore,0,4)
    option = optionSpaceOrUnderscore ;
else
    error('Option must be a number 0, 1, 2, 3, or underscore, space, or dash')
end;  %  

%%  CHANGE ALL THE UNDERSCORES INTO SPACES SO THAT THEY ARE NOT WORD CHARACTERS
output = regexprep(string2clean,'_',' ');

%%  REPLACE ALL THE NON-WORD CHARACTERS WITH SPACES
%      if there are two non-word characters in a row, turn the group of
%      them into a single space
if option == 3
    output = strrep(output,'-','bxz');
    output = strrep(output,'.','wpq');
end;  %  if option == 3

output = regexprep(output,'[\W]+',' ');
output = strtrim(output);

if option == 3
    output = strrep(output,'bxz', '-');
    output = strrep(output,'wpq','.');
end;  %  if option == 3
%%  IF THE SELECTED OPTION WAS FOR UNDERSCORES, REPLACE ALL SPACES WITH UNDERSCORES
if option == 2
    output = strrep(output,' ','_');
end;  %  if option == 2