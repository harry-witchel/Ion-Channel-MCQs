% ion_Transporters_mcq_make
%  This is a script that automatically makes MCQs based on an inputted
%  excel file.  The excel file (variable name = formulary) has nine
%  columns: 1 unused (for administrator), 2 category for test, 
%  3 date of lecture, 4 tranporter name, 5 gene, 6 required functions, 
%  7 extra functions, 8 required inhibitors, 
%  and 9 extra inhibitors.  Most columns can have multiple entries
%  separated by commas.  The script loops through each correct answer 
%  (e.g. a transporter name) and then makes eight or more questions: 
%  1)  Given the gene, what is 
%  the transporter, 2) given the transporter, what is the gene, 3) given the 
%  gene, what is the function, 4) given the function, what is the gene, 
%  5) given the transporter, what is the function, 6) given the 
%  function, what is the transporter, 7) given the transporter, what is the 
%  inhibitor, and 8) given the inhibitor, what is the transporter.  It then matches
%  up each question with a set of randomly selected wrong answers.  Note
%  that both inhibitors and functions from the input sheet comprise
%  two columns: one of required information, and one of extra information
%  that is not tested.  The rationale is that there may be information that
%  the instructor does not want the students to learn (e.g. a rarely used
%  function for a transporter), and the script will not make questions
%  specifically about these extra functions, but it will avoid using that
%  transporter when formulating the list of wrong options relating to that 
%  function.
%
%  The input sheet has two columns for categorising questions, both of
%  which are optional.  In the category column, you can create any
%  categories you want to make separate tests for (for example, "CVS", 
%  "epithelial"),
%  and the script will (if you do not disable it) only select wrong options
%  from transporters in that category.  Thus, if you have a question in the 
%  category of epithelia, wrong options might include Na/H exchanger and Na/K pump, 
%  but not the fast Na+ channel.  The category will also be included on the
%  output, so that you can group similar questions.  If you have multiple
%  categories for a given transporter, and you enable the category feature, 
%  the script will make one question for each category (these will be very 
%  similar questions but with a different set of wrong options).  
%  There is also an option to make versions of the question from
%  all categories in addition to the listed categories.
%
%  Another option is the "date of lecture" column.  This should be a number
%  (such as a date number), a lecture number (e.g. an integer), or a date
%  of the form "2017-01-30" (yyyy-mm-dd).  If you do not disable this
%  feature, the script will only select wrong answers with dates on or
%  before this lecture date.  Note that if you leave the date blank, the
%  default is to include the transporter in all questions (as if it was taught
%  previously).  If you want some transporters only to appear at the end of the
%  course, you should give those transporters a date or a lecture number that is
%  larger than all the others.  If you leave the date column blank, it is
%  ignored (and the output lists the date as negative 1).
%
%  If you choose to use either the date or the category function, you
%  should make sure that the lowest date (or the smallest category) in your
%  formulary has at least the number of options you want, otherwise you
%  will spend a lot of time being prompted to manually enter wrong 
%  options.
%
%  EXTERNAL FUNCTIONS NEEDED TO RUN THIS
%       vert
%       split_string
%       regexpcmp
%       regexpcmpmulti
%       warning_off
%       select_from_list
%       allnines
%       dateToday
%       thisDrive
%       isanumber
%       nameclean
%
%  OUTPUTS:
%       mcqOutputCellArray = cell array (which can be turned into an excel
%           spreadsheet, where each line is one complete MCQ question.  The
%           columns of the spreadhsset are: 'UniqueID','Question Stem',
%           'category', 'lecture date', 'Type of Question',
%           'Correct Answer', 'Wrong Option 1', 'Wrong Option 2', 
%           'Wrong Option 3', 'Wrong Option 4', etc.
%  INPUTS:
%       formulary = an excel spread sheet that is read into Matlab and
%           turned into a cell array by the function xlsread.  The excel
%           workbook should be in the current working directory of Matlab

clear formulary allTransporterNames allFunctions allTransporterGenes allInhibitors
clear mcqOutputCellArray
warning_off

firstQuestionType = 1;  %  normally this is 1.  This is the start of the 
                        %  loops for the different question types

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%   INPUT PRELIMINARY INFORMATION      %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%  ASK MATLAB USER FOR OPTIONS

% fileNameFormulary = input(['Input the file name of your excel file ', ...
%                            'formulary:  '], 's');
% sheetName         = input(['Input the name of the relevant worksheet ', ...
%                            'in your file:  '], 's');
% 
% fprintf('Input the TOTAL number of options in your MCQs, which is \n');
% totalOptions = input...
%     ('the sum of the number of wrong options plus the correct option:  ');
% if ~isscalar(totalOptions)     || ~isnumeric(totalOptions) || ...
%             (floor(totalOptions) ~= totalOptions)          || ...
%             (totalOptions < 0)  || (totalOptions > 11)
%     error('Sorry total options must be a positive integer < 12')
% end;  %  if totalOptions > 11
% 
% askUser = '\nDo you want to use categories to limit the wrong options (Y/N)?  ';
% tfUseCategories = regexpcmp(input(askUser,'s'),'[Yy]');
% 
% askUser = '\nDo you want to use lecture dates to limit the wrong options (Y/N)?  ';
% tfUseDates = regexpcmp(input(askUser,'s'),'[Yy]');
% 
% askUser = '\nDo you want to ask questions about inhibitors (Y/N)?  ';
% tfIncludeInhibitors = regexpcmp(input(askUser,'s'),'[Yy]');


%%  LOAD YOUR OWN OPTIONS AUTOMATICALLY HERE
%     these options allow you to run the script repeatedly without
%     re-entering using input statements.  Note that these statements
%     should normally be commented out.

pathFormulary = fullfile(thisDrive,'30Sept07\2_Teaching', ...
    'Champions of Medicine Question of Anatomy QoA', ...
    'Items and Test Questions\Automated Questions Items for Testing');
fileNameFormulary = 'Ion Transport input data 2018-04-23.xls';
sheetName = 'Data for Matlab';
totalOptions = 5;
tfUseCategories  = false;
tfUseDates    = false;
tfIncludeInhibitors = true;


%%  END OF LOADING YOUR OWN OPTIONS AUTOMATICALLY

%%  LOAD USER'S FORMULARY FROM EXCEL
pathFormulary             = pwd;
[num,txt,formulary]       = xlsread(fullfile(pathFormulary, ...
                            fileNameFormulary),sheetName);
formulary(1,:)            = []; %  eliminate header
numberOfRows              = size(formulary,1);

colCategory               = 2;
colDate                   = 3;
colTransporterName        = 4;  %  this is the column number where the transporter names are
colTransporterGene        = 5;  %  this is the column number where the transporter genes are
colFunction               = 6;
colExtraFunctions         = 7;
colInhibitors             = 8;
colExtraInhibitors        = 9;

%%  CLEAN UP INPUT MATRIX SO THAT THERE ARE STRINGS RATHER THAN NaNs
for j_col = 1:9
    if  ismember(colDate,j_col)
        %  dates are numbers, so skip the date column
        continue;  %   next j_col
    end;  %  if  ismember([colDate],j_col)
    for i_row = 1:size(formulary,1)
        thisEntry = formulary{i_row,j_col};
        if ischar(thisEntry)
            continue;  %  
        elseif isempty(thisEntry) || isnan(thisEntry)
            formulary{i_row,j_col} = '';  %  empty string
        else
            formulary{i_row,j_col} = '';  %  empty string
        end;  %  if ischar(thisEntry)
    end;  %  for i_row
end;  %  for j_col

headerOutput = {'UniqueID','Category','Lecture Date','Type of Question', ...
    'Question Stem', 'Correct Answer', 'Wrong Option 1', ...
    'Wrong Option 2', 'Wrong Option 3', 'Wrong Option 4', 'Wrong Option 5', ...
    'Wrong Option 6', 'Wrong Option 7', ' Wrong Option 8', ...
    'Wrong Option 9', 'Wrong Option 10', 'Wrong Option 11'};
headerOutput = headerOutput(1:(totalOptions + 5));

%%  MAKE SURE DATE COLUMN IS READABLE AS A NUMBER

dateFormat = [];
tfDateFormatIsMixed = false;
for i_dateRow = 1:numberOfRows
    thisDateEntry = formulary{i_dateRow,colDate};
    if isnumeric(thisDateEntry) && isscalar(thisDateEntry) && isnan ...
            (thisDateEntry)
        formulary{i_dateRow,colDate} = -1;
    elseif ischar(thisDateEntry)
        %  this should be in the string format yyyy-mm-dd
        
        try
            newDate = datenum(thisEntry,'yyyy-mm-dd');
        catch
            error('String input in lecture date column not yyyy-mm-dd form')
        end;  %  try
        
        if isempty(dateFormat) 
            dateFormat = 'string';
        end;  %  if isempty(dateFormat) 
        
        if ~strcmp(dateFormat, 'string')
            tfDateFormatIsMixed = true;
        end;  %  if ~isempty(dateFormat)
        
        formulary{i_dateRow,colDate} = newDate;
        
    elseif isanumber(thisDateEntry) && ((thisDateEntry < 1000) || ...
            (thisDateEntry == floor(thisDateEntry)))
        %  this should be a lecture number, leave it alone
        if isempty(dateFormat) 
            dateFormat = 'integers';
        end;  %  if isempty(dateFormat) 
        
        if ~strcmp(dateFormat, 'integers')
            tfDateFormatIsMixed = true;
        end;  %  if ~isempty(dateFormat)
        
    elseif isanumber(thisDateEntry) && ((thisDateEntry > 1000) || ...
           (thisDateEntry ~= floor(thisDateEntry)))
        %  this is a datenumber, leave it alone
        if isempty(dateFormat) 
            dateFormat = 'datenum';
        end;  %  if isempty(dateFormat) 
        
        if ~strcmp(dateFormat, 'datenum')
            tfDateFormatIsMixed = true;
        end;  %  if ~isempty(dateFormat)
        
    else
        % this is for empty or unknown date values
        formulary{i_dateRow,colDate} = -1;
        
    end;  %  if ischar(thisDateEntry)
end;  %  for i_dateRow = 

if tfUseDates && tfDateFormatIsMixed
    fprintf(['Date formats in the input excel fomulary must be uniform.\n',...
             'Date formats can be in one of three formats\n', ...
             '   Integers (lecture numbers)\n   Date Numbers or\n', ...
             '   Character string dates of the format yyyy-mm-dd\n', ...
             'Dates in Excel usually are shown as strings but are\n', ...
             'actually maintained as a datenum format.\n', ...
             'You can leave some or all date entries empty, but\n'])
    error('Dates in the formulary must be in a single format')
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%      MAKE THE OUTPUT       %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

preallocateLength= 2000;
mcqOutputCellArray = cell(preallocateLength,(totalOptions + 5));  % pre-allocate

i_rowTestOutput    = 1;  %  the first row will be a header

%  split_string is an external script that allows you to break up a string
%  with a comma/semicolon into two entries in a list (as a cell string)
allTransporterNames     = unique(split_string(formulary(:,colTransporterName)));
allCategories           = lower(unique(split_string(formulary(:,colCategory))));
allTransporterGenes     = unique(split_string(formulary(:,colTransporterGene)));
allFunctions            = unique(split_string(lower(formulary(:, colFunction))));
allInhibitors           = unique(split_string(lower(formulary(:, ...
                          colInhibitors))));

%%   LOOP THROUGH INDIVIDUAL TRANSPORTERS

for i_rowFormularyInput = 1: numberOfRows
    %  the this's are related to the correct answer
    thisCategory = '';
    thisLectureDate = formulary{i_rowFormularyInput,colDate};
    theseCategories    = split_string(formulary{i_rowFormularyInput, ...
        colCategory}, '[;,]');
    thisTransporterName = split_string(formulary{i_rowFormularyInput,colTransporterName},...
        '[;,]');
    thisTransporterGene = split_string(formulary{i_rowFormularyInput, ...
        colTransporterGene},'[;,]');
    thisFunctions = split_string(lower(formulary{i_rowFormularyInput, ...
        colFunction}),'[;,]');
    thisExtraFunctions = split_string(lower(formulary{i_rowFormularyInput, ...
        colExtraFunctions}),'[;,]');
    thisInhibitors = split_string(lower(formulary{i_rowFormularyInput, ...
        colInhibitors}),'[;,]');
    thisExtraInhibitors = split_string(lower(formulary{i_rowFormularyInput, ...
        colExtraInhibitors}),'[;,]');
    
    %  the question maker will make the same kind of question for each
    %  category, if the category feature is enabled.
    %  the number of category loops has to be a minimum of 1.   
    numberOfCategoryLoops     = numel(theseCategories);
    if ~tfUseCategories || (numberOfCategoryLoops < 1)
        numberOfCategoryLoops = 1;
    end;  %   if ~tfUseCategories 
        
    for  i_category = 1:numberOfCategoryLoops
        if (numel(theseCategories) == 0) 
            thisCategory = '';
            ix_category = ones(size(formulary,1),1);
        else
            thisCategory = theseCategories{i_category};
            ix_category = regexpcmp(formulary(:,colCategory),thisCategory, ...
                'ignorecase');
        end;  %  
        
        %%  SET UP ix_category & ix_date
        %       These are Boolean vectors of the relevant rows to select
        %       wrong options from.  If the options for date or time are
        %       disabled by user, then the relevant vector is just a column
        %       of ones with as many rows as the formulary.
        
        if ~tfUseCategories 
            ix_category = ones(size(formulary,1),1);
        end;  %  if ~tfUseCategories 
              
        if tfUseDates
            ix_date = (cell2mat(formulary(:,colDate)) <= thisLectureDate);
            if thisLectureDate < 0
                ix_date = ones(size(formulary,1),1);
            end;  %  
        else
            ix_date = ones(size(formulary,1),1);
        end;  %  if tfUseDates

        ix_allowedSelections = ix_date(:) & ix_category(:);
            %  these are the indices for possible wrong answers

        %  'relevant' lists represent the potentially wrong answers
        relevantTransporterNames = unique(split_string(formulary ...
                        (ix_allowedSelections,colTransporterName)));
        relevantCategories = lower(unique(split_string(formulary ...
                        (ix_allowedSelections,colCategory))));
        relevantTransporterGenes = unique(split_string(formulary ...
                        (ix_allowedSelections,colTransporterGene)));
        relevantFunctions = unique(split_string(lower(formulary ...
                        (ix_allowedSelections, colFunction))));
        relevantExtraFunctions = unique(split_string(lower(formulary ...
                        (ix_allowedSelections, colExtraFunctions))));
        relevantInhibitors = unique(split_string(lower(formulary ...
                        (ix_allowedSelections, colInhibitors))));
        relevantExtraInhibitors = unique(split_string(lower(formulary ...
                        (ix_allowedSelections, colExtraInhibitors))));

        if tfIncludeInhibitors
            finalQuestionType = 8;
        else
            finalQuestionType = 6;
        end;  %   if tfIncludeInhibitors

        %%  LOOP THROUGH QUESTION/ITEM TYPES
        
        for i_questionType = firstQuestionType:finalQuestionType
            switch i_questionType
                case 1
                    %  given gene, identify transporter
                    givenInfo      = thisTransporterGene;
                    correctAnswers = thisTransporterName;
                    allOptions     = allTransporterNames;
                    questionString = 'The gene %s relates to the ion transporter class:';
                    colAnswerMain  = colTransporterName;
                    colAnswerExtra = NaN;
                    colGivenMain   = colTransporterGene;
                    colGivenExtra  = NaN;
                case 2
                    %  given transporter,  identify the gene
                    givenInfo      = thisTransporterName ;
                    correctAnswers = thisTransporterGene;
                    allOptions     = allTransporterGenes;
                    questionString = 'A major subunit for %s can be encoded by:';
                    colAnswerMain  = colTransporterGene;
                    colAnswerExtra = NaN;
                    colGivenMain   = colTransporterName;
                    colGivenExtra  = NaN;
                case 3
                    %  given gene, identify function
                    givenInfo      = thisTransporterGene;
                    correctAnswers = thisFunctions;
                    allOptions     = allFunctions;
                    questionString = 'The gene %s encodes a protein whose major functions include:';
                    colAnswerMain  = colFunction;
                    colAnswerExtra = colExtraFunctions;
                    colGivenMain   = colTransporterGene;
                    colGivenExtra  = NaN;
                case 4
                    %  given function, identify the gene
                    givenInfo      = thisFunctions;
                    correctAnswers = thisTransporterGene;
                    allOptions     = allTransporterGenes;
                    questionString = '%s is related to the gene:';
                    colAnswerMain  = colTransporterGene;
                    colAnswerExtra = NaN;
                    colGivenMain   = colFunction;
                    colGivenExtra  = colExtraFunctions;
                case 5
                    %  given transporter,  identify function
                    givenInfo      = thisTransporterName;
                    correctAnswers = thisFunctions;
                    allOptions     = allFunctions;
                    questionString = 'Activity of %s contributes to:';
                    colAnswerMain  = colFunction;
                    colAnswerExtra = colExtraFunctions;
                    colGivenMain   = colTransporterName;
                    colGivenExtra  = NaN;
                case 6
                    %  given function, identify tranporter
                    givenInfo      = thisFunctions;
                    correctAnswers = thisTransporterName;
                    allOptions     = allTransporterNames;
                    questionString = '%s is mostly performed by:';
                    colAnswerMain  = colTransporterName;
                    colAnswerExtra = NaN;
                    colGivenMain   = colFunction;
                    colGivenExtra  = colExtraFunctions;
                case 7
                    %  given transporter, identify inhibitor
                    givenInfo      = thisTransporterName;
                    correctAnswers = thisInhibitors;
                    allOptions     = allInhibitors;
                    questionString = '%s can be inhibited at highest affinity by:';
                    colAnswerMain  = colInhibitors;
                    colAnswerExtra = colExtraInhibitors;
                    colGivenMain   = colTransporterName;
                    colGivenExtra  = NaN;
                case 8
                    %  given inhibitor, identify transporter
                    givenInfo = thisInhibitors;
                    correctAnswers = thisTransporterName;
                    allOptions     = allTransporterNames;
                    questionString = '%s is a high affinity inhibitor of:';
                    colAnswerMain  = colTransporterName;
                    colAnswerExtra = NaN;
                    colGivenMain   = colInhibitors;
                    colGivenExtra  = colExtraInhibitors;
            end;  %  switch i_questionType
            
            if ~isnan(colAnswerExtra)
                untestedCorrectAnswers = formulary(i_rowFormularyInput, ...
                                         colAnswerExtra);
                untestedCorrectAnswers = split_string(untestedCorrectAnswers);
            else
                untestedCorrectAnswers = cell(0,1);
            end;  %   if ~isnan(colAnswerExtra)
            
            %%  LOOP THROUGH THE GIVENS

            for i_given = 1:numel(givenInfo)
                thisGiven = givenInfo{i_given};
                questionStem = sprintf(questionString, thisGiven);
                questionStem(1) = upper(questionStem(1));
                
                %%  LOOP THROUGH THE ANSWERS
                
                for i_answer = 1:numel(correctAnswers)
                    thisAnswer = correctAnswers{i_answer};
                    tfAllowedOptions = ones(numberOfRows,3);
                    tfAllowedOptions(:,3) = ix_allowedSelections(:);
                    tfAllowedOptions(:,1) = ~regexpcmpmulti(formulary(:, ...
                        colGivenMain), thisGiven);
                    if ~isnan(colGivenExtra)
                        tfAllowedOptions(:,2) = ~regexpcmpmulti(formulary(:, ...
                            colGivenExtra), correctAnswers);
                    end;  %  if ~isnan(colGivenExtra)
                    tfAllowedRows   = logical(prod(tfAllowedOptions,2));
                    allowedOptions  = formulary( tfAllowedRows, colAnswerMain);
                    allowedOptions  = split_string(allowedOptions,'[;,]');
                    ix_excluded     = regexpcmpmulti(allowedOptions,  ...
                                      [correctAnswers; ...
                                       untestedCorrectAnswers]);
                    allowedOptions(ix_excluded) = [];

                    %%  SELECT WRONG OPTIONS
                    wrongOptions = cell((totalOptions - 1),1);
                    for i_wrong = 1:(totalOptions - 1)
                        %%  IF THERE ARE TOO FEW WRONG OPTIONS
                        if isempty(allowedOptions) 
                            fprintf('\n=================================================\n')
                            fprintf(2,'\n\nYou have run out of wrong options.  \n   ')
                            fprintf('\n\n   The question is\n%s\n',questionStem)
                            fprintf('\n\n   The correct answer is\n%s\n',thisAnswer)
                            inputMssgText = 'Select a wrong option that has not appeared before';
                            [ scalarOutput, selectedString ] = select_from_list ...
                                ( allOptions, inputMssgText );
                            wrongOptions{i_wrong} = selectedString;
                            continue;  %  next i_wrong
                        end;
                            
                        %%  MAKE THE RANDOM SELECTION FROM ONLY THOSE ALLOWED
                        totalAllowed = numel(allowedOptions);
                        i_thisRandom = floor(totalAllowed * rand(1,1)) + 1;
                        selectedString = allowedOptions{i_thisRandom};
                        wrongOptions{i_wrong} = selectedString;
                        allowedOptions(i_thisRandom) = [];
                    end;  %  for i_wrong
                   
                    %%  SAVE EVERYTHING FOR THE QUESTION HERE
                    i_rowTestOutput = i_rowTestOutput + 1;
                    mcqOutputCellArray{i_rowTestOutput,1} = i_rowTestOutput;
                    mcqOutputCellArray{i_rowTestOutput,2} = thisCategory;
                    mcqOutputCellArray{i_rowTestOutput,3} = thisLectureDate;
                    mcqOutputCellArray{i_rowTestOutput,4} = i_questionType;
                    mcqOutputCellArray{i_rowTestOutput,5} = questionStem;
                    mcqOutputCellArray{i_rowTestOutput,6} = thisAnswer;
                    mcqOutputCellArray(i_rowTestOutput,7:(5+totalOptions)) = ...
                        vert(wrongOptions(1:(totalOptions - 1)))';                
                end;  %  for i_answer
            end;  %  for i_given
        end;  %  for i_questionType
   end;  %  for i_category
end;  %  for i_rowFormularyInput

%%  MAKE RANDOMISED VERSION OF LIST OF ITEMS

if size(mcqOutputCellArray,1) < preallocateLength
    %  cut off extra rows from pre-allocation
    mcqOutputCellArray((i_rowTestOutput + 1): end, :) = [];
end;  %  if size(mcqOutputCellArray,1)
ix_randomRows = randperm(i_rowTestOutput - 1);
randomisedItems = mcqOutputCellArray((ix_randomRows + 1), :);
randomisedItems = [headerOutput; randomisedItems];

%%  EXPORT OUTPUT LIST INTO EXCEL

mcqOutputCellArray(1,:) = headerOutput;
outputFileName = nameclean(['Ion transporter MCQs from Matlab ',dateToday],'_');
xlswrite(outputFileName,allInhibitors,'inhibitors');
xlswrite(outputFileName,allFunctions,'transporter functions');
xlswrite(outputFileName,allTransporterGenes,'genes');
xlswrite(outputFileName,allTransporterNames,'transporters');
xlswrite(outputFileName,randomisedItems,'random items');
xlswrite(outputFileName,mcqOutputCellArray,'items');


