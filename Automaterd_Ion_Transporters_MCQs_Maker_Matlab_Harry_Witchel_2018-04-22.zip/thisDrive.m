function output = thisDrive()
%  output = thisDrive()
%  this function helps to let you use a portable drive with matlab files by
%  allowing you to reference a specific folder even when the drive letter
%  changes.  It does this by looking at the name of the drive you are
%  currently in and providing that drive letter plus a colon, e.g. "c:".
%  This can then be bolted onto your pathName using fullfile
output = pwd; 
output = output(1:2);
