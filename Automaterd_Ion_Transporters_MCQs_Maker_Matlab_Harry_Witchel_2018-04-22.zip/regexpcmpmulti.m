function output = regexpcmpmulti(queryStringOrCellArray,cellArrayOfSmallTemplates, optionalMatchCase)
%    output = regexpcmpmulti(queryStringOrCellArray,cellArrayOfSmallTemplates, optionalMatchCase)
%  This script examines a large query string (or set of strings in a cell 
%  string) to see if that query string (or each string in argument 1) contains any of a
%  set of small expressions.  Eg to test whether "Hello World" contains any
%  of the following strings: "or", "Hell" or space.  It uses regexpcmp, so
%  any regular expression will work inside the cellArrayOfSmallTemplates.
%  Default is to 'ignorecase", but you can match case by including the
%  option 'matchcase'.  
% OUTPUTS:
%       output = logical (vector or scalar). Each value corresponds to one
%           value of queryStringOrCellArray, and that value says whether ANY of
%           the possible templates in cellArrayOfSmallTemplates is present
%           in the particular element of queryStringOrCellArray.  If the input 
%           query is a single string, the output is a single logical output.  
%           Otherwise, the 
%           output will be an 1 x N logical vector, where N = the number 
%           of string cells inside queryStringOrCellArray
%  INPUTS
%       queryStringOrCellArray = string or cell string column (1 x N).  you
%           are looking inside each element of this for the values you are
%           searching for.
%       cellArrayOfSmallTemplates = string or cell string (1 x N).  You are
%           searching for whether these values are inside queryStringOrCellArray
%       optionalMatchCase = character string.  Optional input. Can be
%           either 'ignorecase' (default) or 'matchcase'.  You can
%           abbreviate these options as single letters, and the letters can
%           be capital or lower case
%
%  REQUIRED FUNCTIONS (not normally included with Matlab)
%       vert
%       regexpcmp
%
%  VERSION
%       2018-04-09  01.00  As released
%
%  COPYRIGHT
%       Gnu free license.  Free to use or repurpose for academic, 
%           charitable, and non-commercial purposes, with citation to 
%           original. 
%           (c) 2018  Harry J. Witchel (UK)
%           Not currently published

if nargin < 3
    option1 = 'ignorecase';
else
    if regexpcmp(optionalMatchCase,'m','ignorecase')
        option1 = 'matchcase';
    elseif regexpcmp(optionalMatchCase,'i','ignorecase')
        option1 = 'ignorecase';
    else
        option1 = 'ignorecase';
    end;
end;  %  if nargin < 3

output = false;  %  default output

if ~iscolumn(vert(cellArrayOfSmallTemplates))
    error('cellArrayOfSmallTemplates (argument 2) must be a single row or column cell string.')
end;  %  

if iscell(cellArrayOfSmallTemplates)
    %  input is ok
elseif ischar(cellArrayOfSmallTemplates)
    %  convert from string to cellstring
    x{1} = cellArrayOfSmallTemplates;
    cellArrayOfSmallTemplates = x;
else
    error('The search expression (argument 2) must be a string or cell string.')
end;  %  if ~iscell(cellArrayOfSmallTemplates)


if ischar(queryStringOrCellArray)
    numberOfQueries = 1;
elseif iscell(queryStringOrCellArray) || iscellstr(queryStringOrCellArray)
    if size(vert(queryStringOrCellArray),2) > 1
        error('There can only be a single column/row of strings in input cell array (argument 1).')
    end;  %  if size(queryStringOrCellArray,2) > 1

    if iscellstr(queryStringOrCellArray)
        queryStringOrCellArray = vert(queryStringOrCellArray);
        numberOfQueries = size(queryStringOrCellArray,1);
        output = nan(numberOfQueries,1);
    else
        error('input cell array should be a cell string but it is a cell array')
    end;  %  
else
    error(' Query (argument 1) must be a string or a cell array.\n');
end;  %  if ~ischar(queryString)

cellArrayOfSmallTemplates = vert(cellArrayOfSmallTemplates);
if size(cellArrayOfSmallTemplates,2) > 1
    error('There can only be a single column/row of strings in cell array.')
end;  %  if size(cellArrayOfSmallTemplates,2) > 1

%% loop through all the queries
i_query = 1;
while i_query <= numberOfQueries  
    %%  pick thisQuery for this round
    if ischar(queryStringOrCellArray)
        thisQueryString{1} = queryStringOrCellArray;
    else
        %  cell string array
        thisQueryString = queryStringOrCellArray{i_query};
    end;  %  if ischar(queryStringOrCellArray)
    
    %%  loop through all the possible template/expressions to match
    for i_templateExpression = 1: size(cellArrayOfSmallTemplates,1)
        
        thisExpression = cellArrayOfSmallTemplates{i_templateExpression};
        switch option1
            case 'ignorecase'
                thisLogicalOutput = regexpcmp(thisQueryString,thisExpression,'ignorecase');
            case 'matchcase'
                thisLogicalOutput = regexpcmp(thisQueryString,thisExpression);
            otherwise
                thisLogicalOutput = regexpcmp(thisQueryString,thisExpression,'ignorecase');
        end;  % switch option1
        if thisLogicalOutput
            break;  %  escape loop for i_templateExpression, next i_query
            %  as soon as any template fits in the query (is true) the
            %  answer is true, so leave the loop
            %  
        end;  %  if thisLogicalOutput
    end;  %  for i_templateExpression = 1
    
    if numel(cellArrayOfSmallTemplates) == 1  && numel(queryStringOrCellArray) == 1
        output = thisLogicalOutput;
    else
        output(i_query) = thisLogicalOutput;
    end;  %  if numel(cellArrayOfSmallTemplates) == 1

    i_query = i_query + 1;
end;  %  while i_query <= numberOfQueries

output = logical(output);