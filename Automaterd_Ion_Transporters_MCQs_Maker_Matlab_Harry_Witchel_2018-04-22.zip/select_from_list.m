function [ scalarOutput, textOutput ] = select_from_list( textCellsColumn, inputMssgText )
%[ scalarOutput, textOutput ] = select_from_list( textCellsColumn, inputMssgText )
%select_from_list ALLOWS USER TO SEE A LIST OF OPTIONS IN A TEXT CELL ARRAY
%   textCellsColumn = A CELL ARRAY OF TEXT OPTIONS IN COLUMN FORMAT
%   If the user does not like any of the options, they are instructed to
%   type '999', so the referring script should check for 999 using a
%   function such as 'allnines'

    if nargin < 2
        inputMssgText = '';
    end;  %  if nargsin < 2

    if nargin < 1
        error('Input error: select_from_list requires a column of text to choose from\n')
    end;  %  if nargsin < 1
    
    clear scalarOutput textOutput
    textCellsColumn = vert(textCellsColumn);


    fprintf(2,'\n%s \n', inputMssgText);
    fprintf('Please select from the following:\n(Type 999 for none of the above)\n\n');
    for i_row = 1:size(textCellsColumn,1)
        fprintf('%0.2d:  %s    \n', i_row, textCellsColumn{i_row,1}); 
    end;  %  for i_row = 1:size(textCellsColumn,1)
    scalarOutput = input('Input the number corresponding to your choice:  ');
    if allnines(scalarOutput)
        textOutput = 'delete';
    elseif (scalarOutput == floor(scalarOutput)) && (scalarOutput > 0) && (scalarOutput <= size(textCellsColumn,1))
        %  checks if inputted number is an integer or too small or too
        %  large
        textOutput = textCellsColumn{scalarOutput};
    else
        fprintf('Input error: please input an integer between 1 and %d\n', size(textCellsColumn,1));
        [ scalarOutput, textOutput ] = select_from_list( textCellsColumn, inputMssgText );
    end;  %  if allnines(scalarOutput)

end

